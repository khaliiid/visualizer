define(['modules/types/jqgrid/model'], function(model) {

	return model;
});