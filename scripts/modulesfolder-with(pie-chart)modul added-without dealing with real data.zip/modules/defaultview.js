define(['jquery'], function() {

	return {

		init: function() {},
		setModule: function(module) { this.module = module; },

		update: {},
		blank: {},
		onResize: function() {},
		inDom: function() {}

	};
});