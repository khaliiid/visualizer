define(['modules/types/jqgrid/controller'], function(controller) {

	return controller;
});